# TechTest

Some notes about the test.

I created a new project using the Angular CLI as the existing package.json was broken.

I spent more time focusing on code and feature quality so I didnt spend any time writing tests.

All features should work, including filtering, adding, deleting and updating tasks.

There is a single tasks.service.ts file for making API requests.

I use EventEmitters for filtering and opening/closing modal.